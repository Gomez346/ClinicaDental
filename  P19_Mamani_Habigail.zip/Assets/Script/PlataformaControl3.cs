using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlataformaControl3 : MonoBehaviour
{
    public Transform[] plataformas; // Las 4 plataformas a mover
    public Vector3[] posicionesDestino; // Las 4 posiciones de destino
    public float velocidadMovimiento = 2f; // Velocidad de movimiento de las plataformas
    public float tiempoEspera = 1f; // Tiempo que cada plataforma esperar� antes de moverse al siguiente punto

    void Start()
    {
        // Aseg�rate de que haya 4 plataformas y 4 posiciones de destino
        if (plataformas.Length != 4 || posicionesDestino.Length != 4)
        {
            Debug.LogError("Debes asignar 4 plataformas y 4 posiciones de destino.");
            return;
        }

        // Comienza la rutina de movimiento para cada plataforma
        for (int i = 0; i < plataformas.Length; i++)
        {
            StartCoroutine(MoverPlataforma(i));
        }
    }

    private IEnumerator MoverPlataforma(int indice)
    {
        int siguientePosicion = indice; // Comienza en la posici�n actual

        while (true)
        {
            // Calcular la pr�xima posici�n en el patr�n cuadrado
            siguientePosicion = (siguientePosicion + 1) % posicionesDestino.Length;
            Vector3 destino = posicionesDestino[siguientePosicion];

            // Mueve la plataforma hacia la posici�n de destino
            while (Vector3.Distance(plataformas[indice].position, destino) > 0.01f)
            {
                plataformas[indice].position = Vector3.MoveTowards(plataformas[indice].position, destino, velocidadMovimiento * Time.deltaTime);
                yield return null;
            }

            // Espera antes de pasar al siguiente movimiento
            yield return new WaitForSeconds(tiempoEspera);
        }
    }

}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    public float velocidad = 5f;
    public float velocidadArrastrarse = 2f; // Velocidad reducida para arrastrarse
    public float velocidadAumentada = 8f; // Velocidad incrementada cuando se presiona "G"
    public LayerMask capaSuelo;
    public float longitudRaycast = 0.1f;
    public float fuerzaSalto = 5f;
    public float fuerzaRebote = 5f;
    public float maxVelocidadCaida = -15f;

    // Variables de componentes
    private Animator a;
    private SpriteRenderer sr;
    public Animator animator;
    private Rigidbody2D rb;
    private bool ensuelo;
    private bool aumentoVelocidad = false; // Indica si la velocidad est� aumentada

    void Start()
    {
        a = GetComponent<Animator>();
        sr = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Variable de control de movimiento
        float moverx = 0f;
        bool arrastrando = false;

        // Verificar si est� en el suelo utilizando un Raycast
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, longitudRaycast, capaSuelo);
        ensuelo = hit.collider != null;

        // Mostrar el estado de "ensuelo" para asegurarnos de que funciona correctamente
        Debug.Log("En suelo: " + ensuelo);

        // Condici�n para arrastrarse si se presiona "S" y el jugador est� en el suelo
        if (ensuelo && Input.GetKey(KeyCode.S))
        {
            arrastrando = true;
            if (Input.GetKey(KeyCode.D))
            {
                moverx = 1f; // Mover hacia la derecha
                sr.flipX = false; // No invertir el sprite
            }
            else if (Input.GetKey(KeyCode.A))
            {
                moverx = -1f; // Mover hacia la izquierda
                sr.flipX = true; // Invertir el sprite
            }
            moverx *= velocidadArrastrarse / velocidad; // Reducir la velocidad al arrastrarse
            Debug.Log("Arrastrando: " + arrastrando);
        }
        else
        {
            if (Input.GetKey(KeyCode.D))
            {
                moverx = 1f; // Mover hacia la derecha
                sr.flipX = false; // No invertir el sprite
            }
            else if (Input.GetKey(KeyCode.A))
            {
                moverx = -1f; // Mover hacia la izquierda
                sr.flipX = true; // Invertir el sprite
            }
        }

        if (ensuelo && (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W)))
        {
            rb.AddForce(new Vector2(0f, fuerzaSalto), ForceMode2D.Impulse);
        }

        // Control de Animaciones
        animator.SetBool("ensuelo", rb.velocity.y < 0 && !ensuelo);
        animator.SetFloat("movimiento", Mathf.Abs(moverx));
        animator.SetBool("arrastre", arrastrando);

        // Aumento de velocidad solo cuando est� en movimiento y en el suelo
        if (ensuelo && Mathf.Abs(moverx) > 0 && Input.GetKeyDown(KeyCode.G))
        {
            aumentoVelocidad = true;
            animator.SetBool("velocidad", true);
        }
        if (Input.GetKeyUp(KeyCode.G) || !ensuelo || Mathf.Abs(moverx) == 0)
        {
            aumentoVelocidad = false;
            animator.SetBool("velocidad", false);
        }

        // Movimiento f�sico controlado
        float velocidadActual = aumentoVelocidad ? velocidadAumentada : velocidad;
        rb.velocity = new Vector2(moverx * velocidadActual, rb.velocity.y);
    }

    void FixedUpdate()
    {
        if (rb.velocity.y < maxVelocidadCaida)
        {
            rb.velocity = new Vector2(rb.velocity.x, maxVelocidadCaida);
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            // Activa la animaci�n de "golpeado"
            animator.SetBool("golpeado", true);

            // Aplica un rebote al jugador si es necesario
            Vector2 direccionRebote = (transform.position - collision.transform.position).normalized;
            rb.AddForce(direccionRebote * fuerzaRebote, ForceMode2D.Impulse);

            // Aqu� puedes desactivar el bool despu�s de un tiempo, si es necesario
            StartCoroutine(ResetGolpeado());
        }
    }

    private IEnumerator ResetGolpeado()
    {
        yield return new WaitForSeconds(1f); // Espera el tiempo que desees para la animaci�n
        animator.SetBool("golpeado", false); // Desactiva la animaci�n
    }
    void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, transform.position + Vector3.down * longitudRaycast);
    }
}

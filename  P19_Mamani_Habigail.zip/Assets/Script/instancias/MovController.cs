using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovController : MonoBehaviour
{
    public float velocidad = 0.5f;
    public float velocidadCorrer = 1f;
    public float fuerzaSalto = 5f;
    public float longitudRaycast = 0.1f;
    public LayerMask capaTierra;

    
    private Rigidbody2D rb;
    private Animator animator;
    private bool enSuelo;
    private bool corriendo = false;
    private float tiempoEntreAtaques = 0.5f;  // Tiempo en segundos entre ataques
    private float siguienteAtaque = 0f;
   
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        enSuelo = Physics2D.Raycast(transform.position, Vector2.down, longitudRaycast, capaTierra);
        caminar();
        correr();
        saltar();
        ataque();
    }

    private void ataque()
    {
        if (Input.GetMouseButtonDown(0) )
        {
            // Realizar el ataque
            Debug.Log("Ataque");
            animator.SetTrigger("ataque"); 
        }
    }

    private void saltar()
    {
        if (Input.GetKey(KeyCode.Space) && enSuelo)
        {
            animator.SetBool("salto", enSuelo);
            rb.AddForce(new Vector2(0f, fuerzaSalto), ForceMode2D.Impulse);
        }
        if (enSuelo == true)
        {
            animator.SetBool("caida", false);
        }

        if (enSuelo == false)
        {
            animator.SetBool("salto", false);
            animator.SetBool("caida", true);
        }
    }

    private void caminar()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        animator.SetBool("idle", false);

        if (Mathf.Abs(horizontalInput) > 0.1f)
        {
            if (horizontalInput > 0)
            {
                transform.localScale = new Vector3(1, 1, 1);
            }
            else
            {
                transform.localScale = new Vector3(-1, 1, 1);
            }

            float velocidadActual = corriendo ? velocidadCorrer : velocidad;
            rb.velocity = new Vector2(horizontalInput * velocidadActual, rb.velocity.y);

            animator.SetFloat("caminar", Mathf.Abs(horizontalInput));
        }
        else
        {
            rb.velocity = new Vector2(0, rb.velocity.y);
            animator.SetFloat("caminar", 0);
            animator.SetBool("idle", true);
        }
    }

    private void correr()
    {
        if (Input.GetKey(KeyCode.LeftShift))
        {
            corriendo = true;
            animator.SetBool("correr", true);
        }
        else
        {
            corriendo = false;
            animator.SetBool("correr", false);
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Obstaculo") || collision.gameObject.CompareTag("Enemy"))
        {
            VarGlobales.Golpe++;
            if (VarGlobales.Golpe >= 3)
            {
                VarGlobales.vidas--;
            }
        }
        if (VarGlobales.vidas >= 0)
        {
            Debug.Log("sadsad" + collision.name);
        }
    }
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, transform.position + Vector3.down * longitudRaycast);
    }
}

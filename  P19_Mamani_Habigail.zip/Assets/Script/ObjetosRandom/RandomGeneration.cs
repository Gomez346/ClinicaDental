using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomGeneration : MonoBehaviour
{
    // Lista de prefabs a generar
    public List<GameObject> prefabs;

    // �rea de generaci�n (m�ximos y m�nimos de X y Y) en relaci�n al objeto vac�o
    public Vector2 posicionMinima;
    public Vector2 posicionMaxima;

    // Tiempo de intervalo entre generaci�n de objetos
    public float tiempoEntreGeneraciones = 2f;

    void Start()
    {
        // Iniciar la generaci�n de objetos usando InvokeRepeating
        InvokeRepeating("GenerarObjeto", 0f, tiempoEntreGeneraciones);
    }

    void GenerarObjeto()
    {
        // Asegurarse de que la lista de prefabs no est� vac�a
        if (prefabs.Count > 0)
        {
            // Seleccionar un prefab aleatorio de la lista
            GameObject prefabAGenerar = prefabs[Random.Range(0, prefabs.Count)];

            // Generar una posici�n aleatoria dentro del �rea definida por el objeto vac�o
            float posicionAleatoriaX = Random.Range(posicionMinima.x, posicionMaxima.x);
            float posicionAleatoriaY = Random.Range(posicionMinima.y, posicionMaxima.y);
            Vector2 posicionAleatoria = new Vector2(posicionAleatoriaX, posicionAleatoriaY);

            // Instanciar el objeto en la posici�n aleatoria con respecto al objeto vac�o
            Instantiate(prefabAGenerar, (Vector2)transform.position + posicionAleatoria, Quaternion.identity);
        }
    }

    // Funci�n para dibujar el �rea de generaci�n en el Editor
    void OnDrawGizmos()
    {
        // Dibujar un cubo verde con la posici�n del objeto vac�o como centro
        Gizmos.color = Color.green;

        // Obtener el centro del �rea en funci�n de la posici�n del objeto vac�o
        Vector2 centroArea = (posicionMinima + posicionMaxima) / 2;

        // Dibujar un cubo con el tama�o del �rea de generaci�n (basado en las dimensiones de los vectores)
        Gizmos.DrawWireCube((Vector2)transform.position + centroArea, new Vector3(posicionMaxima.x - posicionMinima.x, posicionMaxima.y - posicionMinima.y, 0));
    }
}

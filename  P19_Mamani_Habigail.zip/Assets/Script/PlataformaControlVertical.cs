using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlataformaControlVertical : MonoBehaviour
{
    public float velocidad = 2f;
    public float distanciaPatrulla = 5f;

    private Vector3 posicionInicial;
    private bool moviendoArriba = true;

    void Start()
    {
        posicionInicial = transform.position;
    }

    void Update()
    {
        // Movimiento de patrulla de arriba hacia abajo
        if (moviendoArriba)
        {
            transform.position += Vector3.up * velocidad * Time.deltaTime;
            if (transform.position.y >= posicionInicial.y + distanciaPatrulla)
            {
                moviendoArriba = false;
            }
        }
        else
        {
            transform.position += Vector3.down * velocidad * Time.deltaTime;
            if (transform.position.y <= posicionInicial.y - distanciaPatrulla)
            {
                moviendoArriba = true;
            }
        }
    }
}

  

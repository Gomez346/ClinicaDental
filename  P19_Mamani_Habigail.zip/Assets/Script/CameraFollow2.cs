using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow2 : MonoBehaviour
{
    public Transform player; // Referencia al transform del jugador
    public float smoothSpeed = 0.125f; // Velocidad de suavizado
    public Vector3 offset; // Desplazamiento de la c�mara respecto al jugador

    void LateUpdate()
    {
        if (player != null)
        {
            // Posici�n deseada basada en la posici�n del jugador y el offset
            Vector3 posicionDeseada = player.position + offset;

            // Suavizado de la transici�n para que la c�mara siga suavemente
            Vector3 posicionSuavizada = Vector3.Lerp(transform.position, posicionDeseada, smoothSpeed);

            // Actualizar la posici�n de la c�mara
            transform.position = posicionSuavizada;
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextGolpe : MonoBehaviour
{
    public Text texto;
    // Start is called before the first frame update
    void Start()
    {
        texto.text = $"{VarGlobales.Golpe}";
    }

    // Update is called once per frame
    void Update()
    {
        texto.text = $"{VarGlobales.Golpe}";
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
public class TextVida : MonoBehaviour
{
    public Text texto;
    // Start is called before the first frame update
    void Start()
    {
        texto.text = $"{VarGlobales.vidas}";
    }

    // Update is called once per frame
    void Update()
    {
        
        texto.text = $"{VarGlobales.vidas}";
    }
}

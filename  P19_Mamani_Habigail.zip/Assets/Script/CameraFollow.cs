using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player; // Referencia al jugador
    public float suavizado = 0.3f; // Tiempo de suavizado de la c�mara
    public Vector2 minPos; // Posici�n m�nima (l�mite) que la c�mara puede alcanzar
    public Vector2 maxPos; // Posici�n m�xima (l�mite) que la c�mara puede alcanzar

    private Vector3 velocidad = Vector3.zero;

    void LateUpdate()
    {
        if (player != null)
        {
            // Posici�n deseada basada en la posici�n del jugador
            Vector3 posDeseada = new Vector3(player.position.x, player.position.y, transform.position.z);

            // Suavizado de la transici�n de la c�mara
            Vector3 posSuavizada = Vector3.SmoothDamp(transform.position, posDeseada, ref velocidad, suavizado);

            // Limitar la posici�n de la c�mara para que no salga de los l�mites
            float clampedX = Mathf.Clamp(posSuavizada.x, minPos.x, maxPos.x);
            float clampedY = Mathf.Clamp(posSuavizada.y, minPos.y, maxPos.y);

            // Establecer la nueva posici�n de la c�mara
            transform.position = new Vector3(clampedX, clampedY, transform.position.z);
        }
    }
}

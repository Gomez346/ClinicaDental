using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyControl2 : MonoBehaviour
{
    public float velocidad = 2f;
    public float distanciaPatrulla = 5f;

    private Vector3 posicionInicial;
    private bool moviendoDerecha = true;
    private Rigidbody2D rb;
    private Animator animator;

    void Start()
    {
        posicionInicial = transform.position;
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        // Movimiento de patrulla
        if (moviendoDerecha)
        {
            rb.velocity = new Vector2(velocidad, rb.velocity.y);
            if (transform.position.x >= posicionInicial.x + distanciaPatrulla)
            {
                moviendoDerecha = false;
            }
        }
        else
        {
            rb.velocity = new Vector2(-velocidad, rb.velocity.y);
            if (transform.position.x <= posicionInicial.x - distanciaPatrulla)
            {
                moviendoDerecha = true;
            }
        }

        // Activar la animaci�n de movimiento si se est� moviendo
        //animator.SetBool("moving", rb.velocity.x != 0);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            // Aqu� puedes a�adir l�gica para activar animaci�n de ataque
            animator.SetBool("attacking", true);
            Debug.Log("El enemigo ha golpeado al jugador.");
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            // Detener la animaci�n de ataque al salir de colisi�n
            animator.SetBool("attacking", false);
        }
    }
}

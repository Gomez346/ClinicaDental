using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bala : MonoBehaviour
{
    public float velocidad = 10f;  
    public int da�o = 1;
    public float duracion = 2f;    

    private Vector2 direccion;   

    public void Inicializar(Vector2 direccionDisparo)
    {
        direccion = direccionDisparo;
        Destroy(gameObject, duracion);  
    }

    void Update()
    {
        transform.Translate(direccion * velocidad * Time.deltaTime);
    }
    void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("bals" + collision.gameObject.name);
        if (collision.gameObject.tag == "Enemy")
        {
            Debug.Log("Bala impact� con " + collision.gameObject.name);
            Destroy(gameObject);
        }
    }
}

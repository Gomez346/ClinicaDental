using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disparo : MonoBehaviour
{
    public GameObject balaPrefab;     
    public Transform puntoDisparo;
    public float tiempoEntreDisparos = 0.5f;
    private float proximoDisparo = 0f;
    public int vida = 5;
    public int NumBala = 5;
    void Awake()
    {

        VarGlobales.balas = NumBala;
        VarGlobales.vidas = vida;
    }
    void Update()
    {
        if (Input.GetMouseButton(0) && Time.time >= proximoDisparo &&VarGlobales.balas>0)
        {
            proximoDisparo = Time.time + tiempoEntreDisparos;

            Vector2 direccionDisparo = new Vector2(transform.localScale.x, 0);

            Disparar(direccionDisparo);

            VarGlobales.balas--;
        }
        else
        {
            if (Time.time >= proximoDisparo+1&&VarGlobales.balas <NumBala)
            {
                VarGlobales.balas++;
            }
        }
    }

    void Disparar(Vector2 direccion)
    {
        GameObject bala = Instantiate(balaPrefab, puntoDisparo.position, Quaternion.identity);

        bala.GetComponent<Bala>().Inicializar(direccion);
    }
}

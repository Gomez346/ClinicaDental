using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Areas : MonoBehaviour
{
    [SerializeField] private BoxCollider2D area;

    [SerializeField] private float velocidadlenta = 3f;
    [SerializeField] private float velocidadrapida = 5f;
    Follower follower;
    void Start()
    {
        follower = GetComponentInParent<Follower>();    
    }
    void Update()
    {
        //if (caso == 1)
        //{
        //    //caso1();
        //}
        //else if (caso == 2)
        //{
        //    caso2();
        //}
    }
    private void caso1()
    {
        // Verificar si el jugador est� dentro de la zona de detecci�n
        //if (area.OverlapPoint(player.transform.localPosition) && area)
        //{
        //    Vector2 direccion = player.transform.localPosition - transform.localPosition;
        //    transform.Translate(direccion.normalized * velocidadlenta * Time.deltaTime);
        //}
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (follower != null)
        {
            Debug.Log("asdasd   " + follower.caso.ToString());
        }
        else
        {
            Debug.LogWarning("El componente Follower no est� asignado o es nulo.");
        }
    }

}

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follower : MonoBehaviour
{
    [SerializeField] private GameObject player;
    [SerializeField] private BoxCollider2D areaThis;
    //[SerializeField] private CircleCollider2D areadeteccion;
    //[SerializeField] private CircleCollider2D areapausa;
    [Range(1, 3)][SerializeField] public int caso = 1;
    
    void Start()
    {
        // Inicializaci�n
    }

    

    private void caso2()
    {
        //Debug.Log("caso2");
    }

    


    

}

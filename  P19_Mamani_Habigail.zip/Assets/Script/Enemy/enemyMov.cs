using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyMov : MonoBehaviour
{
    public float velocidad = 2.0f;           
    public float esperaEnPosicion = 1.0f;     
    public float distanciaMaxDerecha = 5.0f;  
    public float distanciaMaxIzquierda = -5.0f; 
    private Animator animador;               
    private bool moviendoDerecha = true;      
    private float posicionInicialX;
    private Transform player;               
    public float rangoDeAtaque = 1.0f;
    private bool estaAtacando = false;

    
    void Start()
    {
        animador = GetComponent<Animator>();
        posicionInicialX = transform.position.x; 
        StartCoroutine(MoverEnemigo());        
    }
    IEnumerator MoverEnemigo()
    {

        while (true)
        {
            if (estaAtacando==false)
            {
                animador.SetBool("run", true);

                float posicionObjetivoX = moviendoDerecha ? posicionInicialX + distanciaMaxDerecha : posicionInicialX + distanciaMaxIzquierda;

                while (Mathf.Abs(transform.position.x - posicionObjetivoX) > 0.1f)
                {
                    float nuevaPosicionX = Mathf.MoveTowards(transform.position.x, posicionObjetivoX, velocidad * Time.deltaTime);
                    transform.position = new Vector2(nuevaPosicionX, transform.position.y);
                    yield return null;
                }

                animador.SetBool("run", false);
                yield return new WaitForSeconds(esperaEnPosicion);

                moviendoDerecha = !moviendoDerecha;

                Vector3 escala = transform.localScale;
                escala.x = moviendoDerecha ? Mathf.Abs(escala.x) : -Mathf.Abs(escala.x);
                transform.localScale = escala;
            }
            else
            {
                yield return null; 
            }

        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        estaAtacando = true;
    }
    void OnTriggerStay2D(Collider2D col)
    {
        Debug.Log("sigue");
        player = col.transform;
        StartCoroutine(AtacarJugador());
    }
    void OnTriggerExit2D(Collider2D col)
    {
        if (col.CompareTag("Player"))
        {
            animador.SetBool("Atacar", false);
            estaAtacando = false; 
        }
    }
    IEnumerator AtacarJugador()
    {
        if (player != null)
        {
            float distancia = Vector2.Distance(transform.position, player.position);

            Debug.Log(distancia);
            //Debug.Log("�Atacando al jugador!");
            animador.SetBool("Atacar",true);

            yield return new WaitForSeconds(esperaEnPosicion);
        }
        
    }
}

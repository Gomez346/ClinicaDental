using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dead : MonoBehaviour
{
    [SerializeField] private BoxCollider2D area;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Verificar que solo se detecte el BoxCollider2D
        if (area && collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("Ha colisionado con un BoxCollider2D");
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlataformaControl : MonoBehaviour
{
    public float velocidad = 2f;
    public float distanciaPatrulla = 5f;

    private Vector3 posicionInicial;
    private bool moviendoDerecha = true;

    void Start()
    {
        posicionInicial = transform.position;
    }

    void Update()
    {
        // Movimiento de patrulla
        if (moviendoDerecha)
        {
            transform.position += Vector3.right * velocidad * Time.deltaTime;
            if (transform.position.x >= posicionInicial.x + distanciaPatrulla)
            {
                moviendoDerecha = false;
            }
        }
        else
        {
            transform.position += Vector3.left * velocidad * Time.deltaTime;
            if (transform.position.x <= posicionInicial.x - distanciaPatrulla)
            {
                moviendoDerecha = true;
            }
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlataformaControl2 : MonoBehaviour
{
    public Vector3[] posiciones; // Array de posiciones a las que se mover� la plataforma
    public float velocidad = 2f; // Velocidad de movimiento de la plataforma
    public float tiempoEspera = 1f; // Tiempo que la plataforma esperar� antes de moverse al siguiente punto

    private int indiceActual = 0; // �ndice de la posici�n actual
    private bool moviendo = true; // Estado para saber si est� moviendo o esperando

    void Start()
    {
        // Inicializa la posici�n de la plataforma en la primera posici�n del array
        transform.position = posiciones[0];
        StartCoroutine(MoverPlataforma());
    }

    private IEnumerator MoverPlataforma()
    {
        while (true)
        {
            if (moviendo)
            {
                // Mover hacia la posici�n objetivo actual
                Vector3 posicionObjetivo = posiciones[indiceActual];
                transform.position = Vector3.MoveTowards(transform.position, posicionObjetivo, velocidad * Time.deltaTime);

                // Si llega a la posici�n objetivo, cambia al siguiente punto despu�s de esperar
                if (Vector3.Distance(transform.position, posicionObjetivo) < 0.01f)
                {
                    moviendo = false;
                    yield return new WaitForSeconds(tiempoEspera);
                    indiceActual = (indiceActual + 1) % posiciones.Length;
                    moviendo = true;
                }
            }
            yield return null;
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CuadradoMovimiento : MonoBehaviour
{
    public List<Transform> platforms; 
    public float speed = 2f;

    private List<Vector2> positions;

    void Start()
    {
        positions = new List<Vector2>();
        foreach (var platform in platforms)
        {
            positions.Add(platform.position);
        }

        for (int i = 0; i < platforms.Count; i++)
        {
            StartCoroutine(MovePlatform(platforms[i], i));
        }
    }

    private IEnumerator MovePlatform(Transform platform, int index)
    {
        while (true)
        {
            int nextIndex = (index + 1) % positions.Count;

            Vector2 targetPosition = positions[nextIndex];

            while ((Vector2)platform.position != targetPosition)
            {
                platform.position = Vector2.MoveTowards(platform.position, targetPosition, speed * Time.deltaTime);
                yield return null;
            }

            index = nextIndex;
            yield return new WaitForSeconds(0.5f);
        }
    }
}
